<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<title>Document</title>
</head>
<body>
	<P><strong>Nombres: </strong>{!!$nombres!!}</P>
	<P><strong>Email: </strong>{!!$email!!}</P>
	<P><strong>Telefono: </strong>{!!$telefono!!}</P>
	<P><strong>Ciudad: </strong>{!!$ciudad!!}</P>
	<P><strong>Mensaje: </strong>{!!$mensaje!!}</P>

</body>
</html>
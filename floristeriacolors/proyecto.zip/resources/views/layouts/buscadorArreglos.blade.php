<section class="bienvenida">
        <div class="container"> 

            <div class="row">
                <div class="col-md-6 text-center saludo">
                   <p>Bienvenido a la Floristeria mas importante de Colombia</p> 
                   <h4>Tu compra segura y 100% garantizada!</h4>
                </div>
                <div class="col-md-6">
                     
                    <div class="input-group">
                                   
                        <input type="text" class="form-control" name="city" placeholder="Buscar arreglo. ej: Arreglo de rosas">
                        <span class="input-group-btn">
                        <button class="btn btn-default" type="button"><span class="fa fa-search fa-1x"></span></button>
                        </span>
                    </div>                             
                                
                            
                </div>
               
                
            </div>

            
        </div>
        
    </section>
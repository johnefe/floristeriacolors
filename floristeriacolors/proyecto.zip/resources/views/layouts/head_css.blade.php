      <!-- head_css-->
        <link href='http://fonts.googleapis.com/css?family=Open+Sans:400,300,600,700,800' rel='stylesheet' type='text/css'>
        <script src="https://use.fontawesome.com/b5998af619.js"></script>
        <script src="/js/jquery-1.11.1.min.js"></script>
        <script src="/js/bootstrap.js"></script>
        <script src="/js/bootstrap-modal.js"></script>
        
         <script src="/js/bootstrap-modalmanager.js"></script>
        <script src="/js/bootstrap.min.js"></script>
        <script src='/js/modernizr-2.6.2.min.js'></script>
        <script src='/js/bootstrap-datepicker/js/bootstrap-datepicker.min.js'></script>
        <!-- Twitter Bootstrap css -->
        <link rel="stylesheet" href='/css/bootstrap.min.css'>
        <!-- jquery.fancybox  -->
        <link rel="stylesheet" href='/css/jquery.fancybox.css'>
        <!-- animate -->
        <link rel="stylesheet" href='/css/carousel.css'>
        <link rel="stylesheet" href='/css/animate.css'>
         <link rel="stylesheet" href='/css/style.css'>
        <!-- Main Stylesheet -->
        <link rel="stylesheet" href='/css/main.css'>
        <!-- media-queries -->
        <link rel="stylesheet" href='/css/media-queries.css'>
        <!-- fonts -->
        <link href="https://fonts.googleapis.com/css?family=Gloria+Hallelujah" rel="stylesheet">
        <link href="https://fonts.googleapis.com/css?family=Advent+Pro" rel="stylesheet">
        <link rel="stylesheet" href='/js/bootstrap-datepicker/css/bootstrap-datepicker.css'>
        
        

        <!--fin head_css -->
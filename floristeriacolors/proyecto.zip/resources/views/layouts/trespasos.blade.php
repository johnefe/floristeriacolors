<!-- tres pasos  -->
            <section id="" class="trespasos">
                <div class="container">
                    <div class="row titulo-pasos" >
                        <div class="col-md-8 col-md-offset-2">
                            <h2>COMPRA TU ARREGLO DE UNA FORMA FÁCIL</h2><br>
                        </div>
                        <div class="col-md-4  trespasos-member text-center">
                            <div class="row">
                                <div class="col-md-12">
                                    <span class="fa fa-shopping-basket
             fa-4x"></span>
                                </div>
                                
                            </div>
                            
                            <h5>Elige tu arreglo y si gustas agrega un detalle especial a tu regalo!</h5>
                        </div>
                        <div class="col-md-4  trespasos-member text-center">
                            <div class="row">
                                <div class="col-md-12">
                                    <span class="fa fa-calendar fa-4x"></span>
                                </div>
                                
                            </div>
                            
                            <h5>Elige la fecha y horario de entrega. Además puedes escibir tu mensaje. </h5>
                        </div>
                        <div class="col-md-4 trespasos-member text-center">
                            <div class="row">
                                <div class="col-md-12">
                                    <span class="fa fa-credit-card  fa-4x"></span>
                                </div>
                                
                            </div>
                            
                            <h5>Efectua el pago. Y lo llevaremos hasta donde tu Destinatario!</h5>
                        </div>
                        <div class="col-md-4 col-md-offset-4 btnn">
                            <a href="" class="">FÁCIL, RÁPIDO Y SEGURO</a>
                        </div>
                    </div>
                </div>

            </section>


      <!-- fin de tres pasos-->
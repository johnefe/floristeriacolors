<!--script necesario para la app web -->
        <a href="javascript:void(0);" id="back-top"><i class="fa fa-angle-up fa-3x"></i></a>

        <!-- Essential jQuery Plugins
        ================================================== -->
        <!-- Main jQuery -->
        
        <script type="text/javascript" src="/js/menu.js"></script>
        <script type="text/javascript" src="/js/slider.js"></script>
        <!-- Single Page Nav -->
        <script src="/js/jquery.singlePageNav.min.js"></script>
        <!-- jquery.fancybox.pack -->
        <script src="/js/jquery.fancybox.pack.js"></script>
        <!-- jquery.isotope -->
        <script src="/js/jquery.isotope.js"></script>
        <!-- jquery.parallax -->
        <script src="/js/jquery.parallax-1.1.3.js"></script>
        <!-- jquery.countTo -->
        <script src="/js/jquery-countTo.js"></script>
        <!-- jquery.appear -->
        <script src="/js/jquery.appear.js"></script>
        <script src="/js/carrito.js"></script>
        <!-- Contact form validation -->
        <script src="http://cdnjs.cloudflare.com/ajax/libs/jquery.form/3.32/jquery.form.js"></script>
        <script src="http://cdnjs.cloudflare.com/ajax/libs/jquery-validate/1.11.1/jquery.validate.min.js"></script>
        <!-- Google Map -->
        <script type="text/javascript" src="http://maps.googleapis.com/maps/api/js?sensor=false"></script>
        <!-- jquery easing -->
        <script src="/js/jquery.easing.min.js"></script>
        <!-- jquery easing -->
        <script src="/js/wow.min.js"></script>
        
        <script>
            var wow = new WOW ({
                boxClass:     'wow',      // animated element css class (default is wow)
                animateClass: 'animated', // animation css class (default is animated)
                offset:       120,          // distance to the element when triggering the animation (default is 0)
                mobile:       false,       // trigger animations on mobile devices (default is true)
                live:         true        // act on asynchronously loaded content (default is true)
              }
            );
            wow.init();
        </script> 
        <!-- Custom Functions -->
        <script src='/js/custom.js'></script>
        

<!--seccion 2 -->
<section id="facts2" class="facts2">
    <div class="parallax-overlay">
        <div class="container">
            <div class="col-md-10 col-md-offset-1">
                <div class="sec-title text-center mb50 wow rubberBand animated" data-wow-duration="1000ms">                      
                    <p class="sec-titler">Expresa tus sentimientos</p>
                </div>
            </div>             
        </div>
    </div>
</section>
<!-- fin seccion2 -->
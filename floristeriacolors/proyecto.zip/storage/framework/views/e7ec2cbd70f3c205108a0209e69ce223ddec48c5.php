<!DOCTYPE html>
<html lang="en" class="no-js">
    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
        <title>Floristería Colors</title>
        <link rel="icon" href="/img/favicon.ico" />
        <link rel="shortcut icon" href="/img/favicon.ico" type="image/x-icon" />       
        <meta name="description" content="">
        <meta name="viewport" content="width=device-width, initial-scale=1">

        <!-- CSRF Token -->
        <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
        <!-- Scripts -->
        <script>
            window.Laravel = <?php echo json_encode([
                'csrfToken' => csrf_token(),
            ]); ?>;

            
         </script>
        
        <?php echo $__env->make('layouts.head_css', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

    </head>
    
    
    <body id="body">
        <?php echo $__env->make('layouts.header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

        <!--separador -->
        <div class="separador">
    
        </div>
        <!--fin separador -->
        <?php echo $__env->yieldContent('content'); ?>

        
        <?php echo $__env->make('layouts.puntoscompra', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        <?php echo $__env->make('layouts.seccion2', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>      
        <?php echo $__env->make('layouts.footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

        <?php echo $__env->make('layouts.script', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    </body>



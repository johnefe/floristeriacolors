<?php $__env->startSection('content'); ?>
	<?php echo $__env->make('alerts.request', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
	
	<div class="col-md-8 col-md-offset-2">
                        <div class="card">
                            <div class="header">
                                <h4 class="title">NUEVO PRODUCTO</h4>
                                  <p class="category">www.floristeriaColors.com</p>
                            </div>
                            <div class="content">
                            <?php echo Form::open(['route'=> 'productos.store', 'method'=>'POST','files' => true]); ?>

                            	 <?php echo $__env->make('product.forms.formProduct', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                           	 <button type="submit" class="btn btn-info btn-fill pull-right">REGISTRAR</button>
    <div class="clearfix"></div>
                           	<?php echo Form::close(); ?>

                            </div>
                        </div>
                    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.adminBase', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
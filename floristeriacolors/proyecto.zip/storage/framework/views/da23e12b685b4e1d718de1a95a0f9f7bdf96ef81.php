<!--seccion 2 -->
        <section id="facts2" class="facts2">
                <div class="parallax-overlay">
                    <div class="container">
                    <br><br><br> 
                        <div class="row  col-md-6 col-md-offset-3"><!--formulario inicios de sesion -->
                         
                        </div><!-- fin formulario inicio de sesion -->
                        <div class="col-md-10 col-md-offset-1">
                            <div class="sec-title text-center mb50 wow rubberBand animated" data-wow-duration="1000ms">
                                                          
                                    <p class="sec-titler">Expresa tus sentimientos</p>
                                    </div>
                        </div>
                        
                    </div>
                </div>
        </section>

        <!-- fin seccion2 -->
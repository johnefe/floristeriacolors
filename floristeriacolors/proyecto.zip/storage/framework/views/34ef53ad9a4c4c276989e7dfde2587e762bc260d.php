<?php $__env->startSection('content'); ?>

<div class="col-md-8 col-md-offset-2">
    <div class="card">
        <div class="header">
            <h4 class="title">MULTIMEDIA</h4>
            <p class="category">www.floristeriaColors.com</p>
        </div>
    </div>
</div>
<div class="col-md-8 col-md-offset-2">
    <div class="card">
        <div class="header">
            <h4 class="title">MI VIDEO EN LA PAGINA AYUDA</h4> 
        </div>
        <div class="content">

        <?php echo Form::model($video,['route'=>['multimedia.update',$video->id],'method'=>'PUT']); ?>


        <div class="row">
                    <div class="col-md-12">
                        <div class="form-group">
                        <?php echo Form::label('link_video','Link Video: '); ?>

                        <?php echo Form::text('link',null,['class'=>'form-control','placeholder'=>'link video']); ?>


                        </div>
                    </div>
                </div>
           <button type="submit" class="btn btn-info btn-fill pull-right">ACTUALIZAR</button>
                <div class="clearfix"></div>

        <?php echo Form::close(); ?>


        </div>
    </div>
</div>

 <?php $__currentLoopData = $sliders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $slider): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
  <div class="col-md-8 col-md-offset-2">
    <div class="card">
        <div class="header">
            <h4 class="title"><?php echo e($slider->ruta); ?></h4>
              
        </div>
        <div class="content">
            <!-- aqui inicia el formulario de crear nuevo post -->
            <?php echo Form::model($slider,['route'=>['sliders.update',$slider->id],'method'=>'PUT','files'=>true]); ?>


                <div class="row">                                      
                    <div class="col-md-12">
                        <div class="form-group">

                            <?php echo Form::label('nombre','Nombre: '); ?>

                            <?php echo Form::text('nombre',null,['class'=>'form-control','placeholder'=>'Nombre']); ?>


                        </div>
                    </div>
                </div>
                <!-- para poner la imagen -->
                <div class="row">
                    <div class="col-md-6">
                        <div class="form-group ">
                           <?php echo Form::file('imagen',['class'=>'form-control','id'=>'files']); ?> 
                            
                      
                        </div>
                                                          
                    </div>
                    <div class="col-md-6">
                      <div class="form-group text-center"  id="list">
                        <img src="/img/arreglos/slider/<?php echo e($slider->imagen); ?>" style="width: 500px;" class="img-responsive">

                      </div>
                    </div>
                </div>
            <!--fin para poner la imagen, cuando termines borras -->
                
                <div class="row">
                    <div class="col-md-12">
                        <div class="form-group">
                            <?php echo Form::label('Descripción'); ?>

                            <?php echo Form::textarea('descripcion',null,['class'=>'form-control','placeholder'=>'Texto del slider','rows'=>'5']); ?>  
                        </div>
                    </div>
                </div>

                <button type="submit" class="btn btn-info btn-fill pull-right">guardar</button>
                <div class="clearfix"></div>
            <?php echo Form::close(); ?>

            <!-- aqui finaliza el formulario de crear post -->
        </div>
    </div>
</div>

  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.adminBase', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
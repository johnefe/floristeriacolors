<div class="row">
                    <div class="col-md-12">
                        <div class="form-group">
                        	<?php echo Form::label('Nombre categoria'); ?>

							<?php echo Form::text('name',null,['class'=>'form-control','placeholder'=>'Ingresa el nombre de la categoria']); ?>

                        </div>
                    </div>
                </div>

                <div class="row">                                      
                	<div class="col-md-12">
            			<div class="form-group">
            			<?php echo Form::label('Tipo','Tipo de Categoria: '); ?>

						<?php echo Form::select('category_type_id',$category_types,null,['class'=>'form-control']); ?>	
            			</div>
        			</div>
				</div>
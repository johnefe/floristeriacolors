<?php $__env->startSection('content'); ?>
<?php echo $__env->make('layouts.buscadorArreglos', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<section class="categoriasFlores">
        <div class="container">
            <div class="row ">
                  <div class="col-md-3">
                       <!--menu categorias -->
                       <?php echo $__env->make('layouts.menuCategorias', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                       <!--fin menu categorias -->
                      
                  </div>
                  <!--slider -->
                  <div class="col-md-9">
                    <div class="sli-container">
                        <ul id="sli" class="sli-wrapper">
                            <?php $__currentLoopData = $sliders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $slider): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                            <?php if($slider->id == 1): ?>
                            <li class="currento"> 
                            <?php else: ?>
                            <li>
                            <?php endif; ?>
                            
                            
                                <img src="/img/arreglos/slider/<?php echo e($slider->imagen); ?>" class="img-responsive" alt="Slider Imagen 1">
                                <div class="caption">
                                    <h3 class="caption-title"><?php echo e($slider->nombre); ?></h3>
                                    <p> <?php echo e($slider->descripcion); ?></p>
                                    
                                </div>
                            </li>  
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>                            
                        </ul>
                        <ul class="sli-controls" id="sli-controls">
                            
                        </ul>
                        
                    </div>
                      
                  </div>

                  <!-- -->                 
            </div>
            <div class="row">
               <!-- arreglos de la respectiva categoria seleccionada -->
                  <div class="col-md-12">
                   
                     <div class="col-md-12">
                          <div class="row ordenar-arreglos">
                            <div class="col-md-7">
                                <h5><strong>Floristeria Colors</strong>/<?php echo e($nombre); ?></h5>
                            </div>
                            <!--
                            <div class="col-md-5">
                                <h5><strong>Ordenar por: </strong><a href="">Todos</a>|<a href="">Menos precio</a>|<a href="">Mayor precio</a></h5>
                            </div>
                            -->
                            
                          </div>
                     </div>
                    <div class=" row col-md-12">
                       <!--listado de arreglos de la categoria seleccionada -->

                            <!-- un arreglo -->

                            <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                             <!-- un arreglo -->
                              <div class="col-md-3 wow fadeInLeft" data-wow-duration="500ms">      
                                  <div class="service-desc text-center">
                                    <img src="/img/arreglos/<?php echo e($product->imagen); ?>" class="img-responsive">
                                          <h3><strong><?php echo e($product->nombre); ?></strong> </h3>

                                          <?php if($product->prices->isEmpty()): ?>
                                          <h3>SIN PRECIO</h3>

                                          <?php else: ?>
                                            <h3>$<?php echo e(number_format($product->prices->first()->precio)); ?></h3>
                                          <?php endif; ?>  
                                         

                                      <div class="ver-boton">
                                         <a href="/arregloSeleccionado/<?php echo e($product->id); ?>" class="btn-ver form-control">VER</a>
                                      </div>  
                                  </div>
                                  
                              </div>
                            <!-- fin un arreglo -->

                             <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                           
                           
                    <!--fin listado de arreglos de la categoria seleccionada  -->
                    </div>
                                         
                  </div>

                  <!-- fin arreglos de la respectiva categoria seleccionada -->
            </div>
            
        </div>
        
    </section>
    <section class="div-descuento">
        <div class="row">
             <div class="col-md-12 text-center"> 
                        <h2>
                            Otros clientes también estan Buscando Arreglos Florales.
                        </h2>
                        <p>
                            Aprovecha ahora y separa tu regálo.!
                        </p>
                      
            </div>
            
        </div>
        
    </section>
    <div class="features">
        <div class="container">
            <div class="row">
                <div class="col-md-10 col-md-offset-1">
                <?php $__currentLoopData = $productosRandom; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $productoRandom): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                 <!-- un arreglo -->
                    <div class="col-md-3 wow fadeInLeft" data-wow-duration="500ms">      
                        <div class="service-desc">
                           <img src="/img/arreglos/<?php echo e($productoRandom->imagen); ?>" class="img-responsive">
                              <h3><strong><?php echo e($productoRandom->nombre); ?></strong></h3>
                              <h4>$<?php echo e(number_format($productoRandom->prices->first()->precio)); ?></h4>
                            <div class="ver-boton">
                              <a href="/arregloSeleccionado/<?php echo e($productoRandom->id); ?>" class=" btn-ver form-control">VER</a>
                            </div>  
                        </div>
                        
                    </div>
                  <!-- fin un arreglo -->
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                 
                   
                                         
                </div>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.base', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
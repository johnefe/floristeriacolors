<?php $__env->startSection('content'); ?>

	<?php echo Form::model($category,['route'=>['categorias.update',$category->id],'method'=>'PUT']); ?>

		<?php echo $__env->make('category.forms.formCategory', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

		<?php echo Form::submit('Actualizar',['class'=>'btn btn-primary']); ?>


	<?php echo Form::close(); ?>



<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->startSection('content'); ?>

<div class="col-md-10 col-md-offset-1">
    <div class="card">
        <div class="header">
            <h4 class="title">PUBLICACIONES EN MI BLOG FLORAL</h4>
            <p class="category">www.floristeriaColors.com</p>
        </div>
        <div class="content table-responsive table-full-width">
            <table class="table table-hover table-striped">
                <thead>
                    <th>#</th>
                    <th>Título</th>
                    
                    <th>Descripción</th>
                    <th>Imagen</th>
                    <th>Acciones</th>
                </thead>
                               
                <?php $__currentLoopData = $articles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $article): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tbody>
                        <td><?php echo e($article->id); ?></td>
                        <td><?php echo e($article->titulo); ?></td>
                        
                        <td><?php echo e($article->descripcion); ?></td>
                        <td><img class="img-responsive" src="/img/arreglos/<?php echo e($article->imagen); ?>" >

                        </td>
                       
                        <td>
                            <a href="/admin/articulos/<?php echo e($article->id); ?>/edit" class="btn btn-success"><span class="fa fa-pencil fa-1x"></span></a>
                           
                            <?php echo Form::open(['route'=>['articulos.destroy',$article->id],'method'=>'DELETE']); ?>

                            <button type="submit" class="btn btn-danger" ><span class="fa fa-trash fa-1x"></span></button>

                            <?php echo Form::close(); ?>

                            
                        </td>
                </tbody>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    
                
            </table>

        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.adminBase', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
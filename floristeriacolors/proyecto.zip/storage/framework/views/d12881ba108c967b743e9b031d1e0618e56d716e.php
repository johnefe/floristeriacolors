<?php $__env->startSection('content'); ?>
                    <div class="col-md-8 col-md-offset-2">
                        <div class="card">
                            <div class="header">
                                <h4 class="title">NUEVO POST FLORAL</h4>
                                  <p class="category">www.floristeriaColors.com</p>
                            </div>
                            <div class="content">
                                <!-- aqui inicia el formulario de crear nuevo producto -->
                                <?php echo Form::model($article,['route'=> ['articulos.update',$article->id], 'method'=>'PUT','files' => true]); ?>

                                 <?php echo $__env->make('article.forms.formArticle', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                             <button type="submit" class="btn btn-info btn-fill pull-right">Guardar</button>
    <div class="clearfix"></div>
                            <?php echo Form::close(); ?>

                                </form>
                                <!-- aqui finaliza el formulario de crear nuevo producto -->
                            </div>
                        </div>
                    </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.adminBase', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
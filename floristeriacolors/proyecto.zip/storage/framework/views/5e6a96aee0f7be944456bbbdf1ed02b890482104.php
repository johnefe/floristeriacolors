<!-- categorias -->
      <section id="features" class="features">
            <div class="container">
                <div class="row">
                    <div class="sec-sub-title text-center wow fadeInRight animated " data-wow-duration="500ms">
                        <p>LOS MAS VENDIDOS </p>
                        <h5>Aquellos que han enamorado a nuestros clientes</h5>
                    </div>

                    <!-- service item -->
                    <div class="col-md-2 col-md-offset-1 wow fadeInLeft" data-wow-duration="500ms">
                        <div class="service-item">
                            <!--<div class="service-icon">
                                
                            </div>-->
                            
                            <div class="service-desc">
                                
                               
                                 <img src="img/rosas.jpg" class="img-responsive">
                                  <h3>Rosas!</h3>
                                  <h3>COP 40.000</h3>
                            </div>
                        </div>
                    </div>
                    <!-- end service item -->
                    
                    <!-- service item -->
                    <div class="col-md-2  wow fadeInUp" data-wow-duration="500ms" data-wow-delay="500ms">
                        <div class="service-item">
                                                    
                            <div class="service-desc">
                               
                                 <img src="img/cesta.jpg" class="img-responsive">
                                  <h3>Romance!</h3>
                                  <h3>COP 50.000</h3>
                            </div>
                        </div>
                    </div>
                    <!-- end service item -->
                    
                    <!-- service item -->
                    <div class="col-md-2 wow fadeInRight" data-wow-duration="500ms"  data-wow-delay="900ms">
                        <div class="service-item">
                                                        
                            <div class="service-desc">
                                
                                
                                 <img src="img/flor_violeta.jpg" class="img-responsive">
                                 <h3>Canastas!</h3>
                                 <h3>COP 30.000</h3>
                            </div>
                        </div>
                    </div>
                    <!-- end service item -->
                    <!-- service item -->
                    <div class="col-md-2 wow fadeInRight" data-wow-duration="500ms"  data-wow-delay="900ms">
                        <div class="service-item">
                                                        
                            <div class="service-desc">
                                
                                
                                 <img src="img/spanish_roses.jpg" class="img-responsive">
                                 <h3>Canastas!</h3>
                                 <h3>COP 20.000</h3>
                            </div>
                        </div>
                    </div>
                    <!-- end service item -->
                    <!-- service item -->
                    <div class="col-md-2 wow fadeInRight" data-wow-duration="500ms"  data-wow-delay="900ms">
                        <div class="service-item">
                                                    
                            <div class="service-desc">
                                
                                
                                <img src="img/canasta2.jpg" class="img-responsive">
                                <h3>Exóticos & Diseño!</h3>
                                <h3>COP 30.000</h3>
                            </div>
                        </div>
                    </div>
                    <!-- end service item -->
                     
                     <!-- boton ver todas categorias -->
                        <div class="col-md-4 col-md-offset-4">
                            <div class="btn-categorias">
                                <a href="">VER TODOS LOS ARREGLOS</a>
                            </div>
                        </div>
                     <!-- fin btn-->   
                    <div class="col-md-12 text-center">
                     <hr><h3>"Con Floristería Colors expresas tus sentimientos."</h3><hr>
                    </div>
                </div>
            </div>
        </section>

      <!-- fin categorias -->
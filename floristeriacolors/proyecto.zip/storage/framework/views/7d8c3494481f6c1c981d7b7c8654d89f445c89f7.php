<?php $__env->startSection('content'); ?>

<?php if(Session::has('message')): ?>

<div class="alert alert-success alert-dismissible" role="alert">
  <button type="button" class="close" data-dismiss="alert" aria-label="Close">
  <span aria-hidden="true">&times;</span></button>
  <?php echo e(Session::get('message')); ?></div>

<?php endif; ?>
<?php if(Session::has('error')): ?>

<div class="alert alert-danger alert-dismissible" role="alert">
  <button type="button" class="close" data-dismiss="alert" aria-label="Close">
  <span aria-hidden="true">&times;</span></button>
  <?php echo e(Session::get('error')); ?></div>

<?php endif; ?>
<div class="col-md-5">
    <div class="card">
        <div class="header">
            <h4 class="title">DESTACADOS</h4>
            <p class="category">www.floristeriaColors.com</p>
        </div>
        <div class="content table-responsive table-full-width">
        
            <table class="table table-hover table-striped">
                <thead>
                    <th>Id</th>
                    <th>Producto</th>
                   
                </thead>
                <tbody>
                <!--inicio un precio-->

                    
                    <?php $__currentLoopData = $productos_populares; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $producto_popular): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>

                    <td><?php echo e($producto_popular->product->id); ?></td>
                        <td><?php echo e($producto_popular->product->nombre); ?></td>
                        <td>
                        <?php echo Form::open(['route'=>['destacados.destroy',$producto_popular->id],'method'=>'DELETE']); ?>

                        
                            <button type="submit" class="btn btn-danger" ><span class="fa fa-trash fa-1x"></span></button>
                        <?php echo Form::close(); ?>

                            
                            
                        </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
                        
                    
                
                </tbody>
            </table>

        </div>
    </div>
</div>
<div class="col-md-7">
    <div class="card">
        <div class="header">
            <h4 class="title">ADICIONAR PRODUCTO A DESTACADOS</h4>

        </div>
        <div class="content">
            <?php echo Form::open(['route'=> 'destacados.store', 'method'=>'POST']); ?>

              
                <div class="row">
                    
                    <div class="col-md-6">
                        <div class="form-group">
                            <label>Escoge el producto</label>
                            <?php echo Form::select('product_id',$productos,null,['class'=>'form-control']); ?>   
                           
                        </div>
                    </div>
                </div>

                <button type="submit" class="btn btn-info btn-fill pull-right">ADICIONAR</button>
                <div class="clearfix"></div>
            <?php echo Form::close(); ?>

        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.adminBase', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
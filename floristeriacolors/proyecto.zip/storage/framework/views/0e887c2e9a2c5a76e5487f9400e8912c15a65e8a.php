<?php $__env->startSection('content'); ?>
<div class="col-md-10 col-md-offset-1">
    <div class="card">
        <div class="header">
            <h4 class="title">LISTADO VENTAS</h4>
            <p class="category">www.floristeriaColors.com</p>
        </div>
        <div class="content table-responsive table-full-width">
            <table class="table table-hover table-striped">
                <thead>
                    
                    <th>Fecha venta</th>
                    <th>ID Carrito</th>
                    <th>Cliente</th>
                    <th>Valor</th>
                    <th>Estado</th>
                    <th>Acción</th>
                </thead>
                <tbody>
                <!--inicio un movimiento-->
                <?php $__currentLoopData = $carts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cart): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
                    <tr>
                        <td><?php echo e($cart->fecha_compra); ?></td>
                        <td><?php echo e($cart->id); ?></td>
                        <td><?php echo e($cart->client->nombres); ?> <?php echo e($cart->client->apellidos); ?></td>
                        <td><?php echo e(number_format($cart->total_carrito())); ?></td>
                        <td>
                        <?php if($cart->was_payed): ?>
                            Confirmado
                        <?php else: ?>
                         Sin confirmar

                        <?php endif; ?>

                        </td>
                        <td>
                         <?php if($cart->was_payed): ?>
                            <a href="#info" data-type="zoomin" id="btn-ver<?php echo e($cart->id); ?>" onclick="verbtn(<?php echo e($cart->id); ?>)" class="btn btn-success">ver</a>
                        <?php else: ?>
                          <a href="#info" data-type="zoomin" id="btn-ver<?php echo e($cart->id); ?>" onclick="verbtn(<?php echo e($cart->id); ?>)" class="btn btn-danger">ver</a>

                        <?php endif; ?>
                        
                           
                            
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                   
                <!-- finr un movimiento -->      
                </tbody>
            </table>

        </div>
    </div>
</div>

<?php $__currentLoopData = $carts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cart): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 

<div class="overlay-container" id="o<?php echo e($cart->id); ?>">
        <div class="window-container zoomin card" id="w<?php echo e($cart->id); ?>">
            <span class="fa fa-times-circle-o fa-2x" id="close<?php echo e($cart->id); ?>"></span><br>
        <div class="pp">
            <div class="header text-center">
                    <h3 class="title"><strong>CARRITO DE COMPRAS # <?php echo e($cart->id); ?></strong> </h3>
                </div>  
            <hr>
            <!-- ****************************************************** -->
            <div class="col-md-8 col-md-offset-2 text-left">
                  <!-- un producto -->
                    <div class="row">
                        <div class="content table-responsive table-full-width">
                            <table class="table table-hover table-striped">
                                <thead>
                                    <th>Imagen</th>
                                    <th>Categoria</th>
                                    <th>Nombre</th>
                                    <th>Cantidad</th>
                                    <th>Valor</th> 
                                </thead>
                                <tbody>
                                <!--inicio un movimiento-->
                                <?php $__currentLoopData = $cart->details; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $detail): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 

                                    <tr>
                                        <td>
                                            <img class="img-responsive" style="width: 50px;" src="/img/arreglos/<?php echo e($detail->product->imagen); ?>">
                                        </td>
                                        <td><?php echo e($detail->product->nombre); ?></td>
                                        <td><?php echo e($detail->tamano); ?></td>
                                        <td><?php echo e($detail->cantidad); ?></td>
                                        <td><?php echo e(number_format($detail->precio)); ?></td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                   
                                <!-- finr un movimiento --> 
                                       
                                
                                </tbody>
                            </table>

                        </div>
                        <!--DETALLES DEL COMPRADOR -->
                        <hr>
                        <div class="row text-center">
                        <div class="col-md-12"><h3> <strong>DATOS CLIENTE</strong></h3></div>
                            <!-- UN DATO-->
                            <div class="col-md-12">
                                <div class="form-group">
                                    <div class="col-md-4 text-left">
                                        <label><strong>NOMBRES Y APELLIDOS:</strong></label>
                                    </div>
                                    <div class="col-md-8 text-left">
                                        <p> <?php echo e($cart->client->nombres); ?> <?php echo e($cart->client->apellidos); ?></p>
                                    </div>
                                </div>
                                
                            </div>
                            <!--FIN UN DATO -->
                            <!-- UN DATO-->
                            <div class="col-md-12 text-left">
                               
                                <div class="form-group">
                                    <div class="col-md-4">
                                        <label><strong>IDENTIFICACIÓN:</strong></label>
                                    </div>
                                    <div class="col-md-8 text-left">
                                        <p> <?php echo e($cart->client->identificacion); ?> </p>
                                    </div>
                                </div>
                            </div>
                            <!--FIN UN DATO -->
                            <!-- UN DATO-->
                            <div class="col-md-12">
                                  <div class="form-group text-left">
                                    <div class="col-md-4">
                                        <label><strong>TELÉFONO:</strong></label>
                                    </div>
                                    <div class="col-md-8 text-left">
                                        <p> <?php echo e($cart->client->celular); ?> </p>
                                    </div>
                                </div>
                            </div>
                            <!--FIN UN DATO -->
                        </div>
                        <!--FIN DETALLES DEL COMPRADOR -->
                        <!--DETALLES DEL DESTINATARIO -->
                        <hr>
                        <div class="row ">
                            <div class="col-md-12 text-center">

                                <h3><strong>DATOS DESTINATARIO</strong></h3>
                            </div>
                            <!-- UN DATO-->
                            <div class="col-md-12">
                                <div class="form-group">
                                    <div class="col-md-4">
                                        <label><strong>NOMBRES:</strong></label>
                                    </div>
                                    <div class="col-md-8 text-left">
                                        <p><?php echo e($cart->para); ?></p>
                                    </div>
                                </div>
                            </div>
                            <!--FIN UN DATO -->
                            <!-- UN DATO-->
                            <div class="col-md-12">
                                 <div class="form-group">
                                    <div class="col-md-4">
                                        <label><strong>DIRECCIÓN:</strong></label>
                                    </div>
                                    <div class="col-md-8 text-left">
                                        <p><?php echo e($cart->direccion); ?></p>
                                    </div>
                                </div>
                            </div>
                            <!-- UN DATO-->
                            <div class="col-md-12">
                                <div class="form-group">
                                    <div class="col-md-4">
                                        <label><strong>FECHA ENTREGA:</strong></label>
                                    </div>
                                    <div class="col-md-8 text-left">
                                        <p><?php echo e($cart->fecha_entrega); ?></p>
                                    </div>
                                </div>
                            </div>
                            <!--FIN UN DATO -->
                            <!-- UN DATO-->
                            <div class="col-md-12">
                               <div class="form-group">
                                    <div class="col-md-4">
                                        <label><strong>MENSAJE:</strong></label>
                                    </div>
                                    <div class="col-md-8 text-left">
                                        <p><?php echo e($cart->mensaje); ?></p>
                                    </div>
                                </div>
                            </div>
                            <!--FIN UN DATO -->
                            <!-- UN DATO-->
                            <div class="col-md-12">
                                <div class="form-group">
                                    <div class="col-md-4">
                                        <label><strong>OBSERVACIÓN:</strong></label>
                                    </div>
                                    <div class="col-md-8 text-left">
                                        <p><?php echo e($cart->observacion); ?></p>
                                    </div>
                                </div>
                            </div>
                            <!--FIN UN DATO -->
                        </div>
                        <!--FIN DETALLES DEL DESTINATARIO -->
                        <div class="col-md-9 col-md-offset-2 text-center">
                            <h4><strong>TOTAL: <?php echo e(number_format($cart->total_carrito())); ?></strong></h4>
                        </div>
                        <?php if(!$cart->was_payed): ?>

                        <div class="col-md-9 col-md-offset-2 text-center">
                        <?php echo Form::model($cart,['route'=>['cart.update',$cart->id],'method'=>'PUT']); ?>

                        <input type="hidden" name="was_payed" value="1">
                        
                        <?php echo Form::submit('Confirmar Compra',['class'=>'btn btn-danger']); ?>

                            <?php echo Form::close(); ?>

                        
                           
                        </div>
                           
                        <?php else: ?>
                        

                        <?php endif; ?>
                        
                    </div> 
                <!-- fin un producto --> 
            </div>     
            <!--******************************************************* -->
        </div>
                
            
        </div>
        
</div>

<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<!-- un carrito-->

<!-- fin un carrito  -->

<!-- ******************************************************************* -->
<script>!window.jQuery && document.write(unescape('%3Cscript src="jquery-1.7.1.min.js"%3E%3C/script%3E'))</script>
    <script type="text/javascript" src="/assets/js/demo.js"></script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.adminBase', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
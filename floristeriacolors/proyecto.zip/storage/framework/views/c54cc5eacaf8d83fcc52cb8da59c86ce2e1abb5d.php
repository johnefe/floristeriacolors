<div class="contenedor-menu">
                                <!-- -->
                                <ul id="accordion" class="accordion">
                                    <li>
                                        <div class="link"><a rel="nofollow" rel="noreferrer" href="/arreglos">Todos los Arreglos</a></div>
                                    </li>
                                    <li>
                                        <div class="link"><a rel="nofollow" rel="noreferrer" href="/arreglos/destacados/1">Los mas vistos</a></div>
                                    </li>
                                    
                                    <li>
                                        <div class="link">Categorias<i class="fa fa-chevron-down"></i></div>
                                        <ul class="submenu">
                                        <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        
                                        <li><a rel="nofollow" rel="noreferrer" href="/arreglos/categorias/<?php echo e($category->id); ?>"><?php echo e($category->name); ?></a></li>

                                        
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                        </ul>
                                    </li>
                                    <li><div class="link">Ocasiones<i class="fa fa-chevron-down"></i></div>
                                        <ul class="submenu">
                                         <?php $__currentLoopData = $ocasiones; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ocasion): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                         <li><a rel="nofollow" rel="noreferrer" href="/arreglos/ocasiones/<?php echo e($ocasion->id); ?>"><?php echo e($ocasion->ocasion); ?></a></li>

                                         <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                        </ul>
                                    </li>
                                    <li>
                                        <div class="link"><a rel="nofollow" rel="noreferrer" href="/arreglos/mas_vendidos/1">Los mas vendidos</a></div>
                                    </li>

                                </ul>
                            <!-- -->
                        </div>                       
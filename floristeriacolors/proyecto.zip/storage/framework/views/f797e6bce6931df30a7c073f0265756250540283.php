<?php $__env->startSection('content'); ?>

<?php echo $__env->make('layouts.buscadorArreglos', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

    <section class="categoriasFlores">
        <div class="container">
            <div class="row ">
                  <div class="col-md-3">
                       <!--menu categorias -->
                       <?php echo $__env->make('layouts.menuCategorias', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                       <!--fin menu categorias -->
                      
                  </div>

                  <!--slider -->
                  <div class="col-md-9">
                    <div class="sli-container">
                        <ul id="sli" class="sli-wrapper">
                            <?php $__currentLoopData = $sliders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $slider): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            
                            <li class="currento">
                                <img src="/img/slider/<?php echo e($slider->imagen); ?>" class="img-responsive" alt="Slider Imagen 1">
                                <div class="caption">
                                    <h3 class="caption-title"><?php echo e($slider->nombre); ?></h3>
                                    <p> <?php echo e($slider->descripcion); ?></p>
                                    
                                </div>
                            </li>  
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>                          
                        </ul>
                        <ul class="sli-controls" id="sli-controls">
                            
                        </ul>
                        
                    </div>
                      
                  </div>

                  <!-- -->


                 
            </div>
            
        </div>
        
    </section>

    <section class="div-descuento">
        <div class="row">
             <div class="col-md-12 text-center"> 
                        <h2>
                            Regala amor con nuestras Flores este 8 de Marzo, Día de la Mujer.
                        </h2>
                        <h3>
                            Aprovecha ahora y Obtén un 5% de descuento
                        </h3>
                        <p>
                            Ingresa el cupón MUJER al terminar la compra.
                        </p>
                      
                  </div>
            
        </div>
    </section>
<?php echo $__env->make('layouts.categorias', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
     <section class="div-ofertas">
        <div class="container">
            <div class="row">
                <div class="col-md-12 text-center"> 
                        <h2>
                            Siempre mantenemos ofertas del mes!
                        </h2>
                        <h3>
                            Aprovecha ofertas hasta de un <strong>40% OFF</strong>..!
                        </h3><br>
                        <a href="" class="btn-v">VER ARREGLOS</a>
                      
                </div>
            
        </div>
            
        </div>
        
    </section>
    
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.base', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
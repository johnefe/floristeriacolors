<?php $__env->startSection('content'); ?>
 <!-- seccion 1  -->

        <section id="blog" class="blog">
            <div class="parallax-overlays">
                <div class="container">
               
                   <div class="row ">
                        <div class="col-md-12 text-center"><br>
                            <h2>NUESTRO BLOG FLORAL</h2>
                        </div><br>


                     <!--un post -->   
                     <?php $__currentLoopData = $articles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $article): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                     <div class="col-md-10 col-md-offset-1 post-floral ">
                        <div class="col-md-12 text-center">
                            <h3><strong><?php echo e($article->titulo); ?></strong></h3>
                        </div>
                        
                        <div class="col-md-3 img-post">
                            <img src="/img/arreglos/<?php echo e($article->imagen); ?>" class="img-responsive ">
                        </div>
                        <div class="col-md-9 texto-blog">
                            <p>
                            <?php echo e($article->descripcion); ?>

                            </p>
                        </div>
                        
                    </div> 

                     <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    
                                        
                   </div>
                                        
                </div>
            </div>
        </section>
      <!-- fin seccion 1-->

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.base', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->startSection('content'); ?>


<div class="col-md-6">
<div class="col-md-12">

    <div class="card">
        <div class="header">
            <h4 class="title">REGISTRAR OCASIÓN</h4>
            <p class="category">www.floristeriaColors.com</p>

        </div>
        <div class="content">
             <?php echo Form::open(['route'=> 'ocasiones.store', 'method'=>'POST']); ?>

                <div class="row">
                    <div class="col-md-12">
                        <div class="form-group">
                        <?php echo Form::label('Nombre ocasión:'); ?>

                        <?php echo Form::text('ocasion',null,['class'=>'form-control','placeholder'=>'Escribe el nombre de la ocasión']); ?>

                        </div>
                    </div>
                </div>

                <button type="submit" class="btn btn-info btn-fill pull-right">REGISTRAR</button>
                <div class="clearfix"></div>
            <?php echo Form::close(); ?>

        </div>
    </div>
</div>
<div class="col-md-12">
    <div class="">
    <div class="card">
        <div class="header">
            <h4 class="title">OCASIONES REGISTRADAS</h4>
                    </div>
        <div class="content table-responsive table-full-width">
            <table class="table table-hover table-striped">
                <thead>
                    <th>Nombre</th>
                    <th>Acciones</th>
                    
                </thead>
                <tbody>

                <!--inicio una categoria -->
                <?php $__currentLoopData = $ocasiones; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ocasion): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                 <tr>
                        <td><?php echo e($ocasion->ocasion); ?></td>
                        <td>
                            <button type="submit" class="btn btn-success" ><span class="fa fa-pencil fa-1x"></span></button>
                            <button type="submit" class="btn btn-danger" ><span class="fa fa-trash fa-1x"></span></button>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                   
                <!-- fin una categoria-->
                    
                </tbody>
            </table>

        </div>
    </div>
</div>
</div>
</div>

<div class="col-md-6">
    <div class="card">
        <div class="header">
            <h4 class="title">ADICIONAR PRODUCTO A OCASIÓN</h4>

        </div>
        <div class="content">
        <script>
    $(document).ready(function(){
        $('#occasion_id').change(function(){
            $.get('/dropdown/'+$(this).val(),
            function(data) {
                console.log(data)
                $.get('/productos',function(productos){
                    $('#checkboxes').empty();
                    $.each(productos, function(key, element) {
                        if(BuscarProducto(data,element)) {
                            console.log("encontrado")

                            $('#checkboxes').append(' <label for="one" class="form-control"> <input type="checkbox" onclick="javascript:validar(this);" id="" checked="" /> '+ element.nombre + '</label>');
                            
                          
                        }
                        else {
                              $('#checkboxes').append(' <label for="one" class="form-control"> <input type="checkbox" onclick="javascript:validar(this);" id="" /> '+ element.nombre + '</label>');
                              console.log("no encontrado")
                        }
                    });

                   /* $.each(data, function(key, element) {
                    $('#checkboxes').append(' <label for="one" class="form-control"> <input type="checkbox" id="" /> '+ element.nombre + '</label>');
                    });*/



                 });//cierra get Productos      
                
            });//ciera funcion y get dropdown
        });//cierra funcion change
    });  
    function BuscarProducto(productos,producto){
        var retorno = false;


        productos.forEach(function (k, index, productos){
            console.log("el k")
            console.log(k.id)
            console.log(producto.id)
            
            if(k.id == producto.id) {
                console.log("lo encontro")
                retorno = true;
               
            }

        });
        return retorno;


    }   
</script>

             <?php echo Form::open(['route'=> 'productosOcasiones.store', 'method'=>'POST']); ?>

              
                <div class="row">
                    
                    <div class="col-md-12">
                        <div class="form-group text-center">

                        <h3>Listas vinculadas</h3>

                        <?php echo e(Form::open()); ?>

                        <?php echo Form::label('Ocasion','Escoge la ocasion:'); ?>

                            <?php echo Form::select('occasion_id',$occasions,null,['class'=>'form-control', 'id' =>'occasion_id' ]); ?>  
                        <br>
                        <?php echo e(Form::close()); ?>

                        </div>

                        <div class="form-group">
                            <form>
                              <div class="multiselect">
                                <div class="selectBox "  onclick="showCheckboxes()" >
                                  <select class="form-control">
                                    <option><?php echo Form::label('Product','Escoge el producto'); ?></option>
                                  </select>
                                  <div class="overSelect"></div>
                                </div>
                                <div id="checkboxes">
                                  
                                </div>
                              </div>
                            </form>
                        </div>
                    </div>
                     
                </div>

                <!--<button type="submit" class="btn btn-info btn-fill pull-right">ADICIONAR</button>-->
                <div class="clearfix"></div>
            <?php echo Form::close(); ?>

        </div>
    </div>
</div>

<script type="text/javascript">
    var expanded = false;

function showCheckboxes() {
  var checkboxes = document.getElementById("checkboxes");
  if (!expanded) {
    checkboxes.style.display = "block";
    expanded = true;
  } else {
    checkboxes.style.display = "none";
    expanded = false;
  }
}

function validar(obj){
    if(obj.checked==true){
        alert("si");
    }else{
        alert("no");
    }
}
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.adminBase', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
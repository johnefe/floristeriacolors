<?php $__env->startSection('content'); ?>

<div class="col-md-8">
    <div class="card">
        <div class="header">
            <h4 class="title">EDITAR PRECIO</h4>
            <p class="category">www.floristeriaColors.com</p>

        </div>
        <div class="content">
        	<?php echo Form::model($price,['route'=>['precios.update',$price->id],'method'=>'PUT']); ?>

        		<?php echo $__env->make('price.forms.formPrice', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                <?php echo Form::submit('Guardar',['class'=>'btn btn-info btn-fill pull-right']); ?>

                <div class="clearfix"></div>
            <?php echo Form::close(); ?>

        </div>
    </div>
</div>



<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.adminBase', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
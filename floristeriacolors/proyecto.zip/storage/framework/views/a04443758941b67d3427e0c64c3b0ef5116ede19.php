 <!--puntos por compra -->
        <section id="" class="puntos">
            <div class="container">
                <div class="row" >

                    <div class="col-md-4 puntos-win">
                        <div class="devider1 text-center">
                            <span class="fa fa-star fa-2x"></span>
                            <span class="fa fa-star fa-2x"></span>
                            <span class="fa fa-star fa-2x"></span>
                            <span class="fa fa-star fa-2x"></span>
                            <span class="fa fa-star fa-2x"></span>
                        </div>
                        <div class="win text-center">
                             <p>
                            Con <strong>Floristeria Colors</strong> Ganas Puntos en cada compra que realices y puedes utilizalos <h5>para pagar tus proximos arreglos.!</h5>
                        </p>
                            <a href="" class="ver-info-puntos form-control">Ver mas Información</a>
                        </div>
                       
                    </div>
                    <div class="col-md-4 flores " >
                       <h4 class="text-center">¿COMO CUIDAR TUS FLORES ?</h4>
                       <img src="img/flores.png" class="img-responsive ">
                    </div>

                     <div class="col-md-4 flores2 " >
                       <h4 class="text-center">PLANTA UN ÁRBOL MEMORIAL </h4>
                       <img src="img/arbol.png" class="img-responsive ">
                    </div>
                    
                </div>
            </div>

        </section>


        <!-- fin puntos por compra -->
        
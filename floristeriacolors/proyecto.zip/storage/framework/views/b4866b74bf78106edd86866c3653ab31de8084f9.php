<?php $__env->startSection('content'); ?>

<?php echo $__env->make('layouts.buscadorArreglos', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<section class="menu-carrito">
    <div class="row">
        <div class="col-md-4 col-md-offset-2 col-sm-12 text-center">
            
            <h4>Hay <strong id="cantidad">0</strong> productos en tu carrito de compras</h4>
        </div>
       
                <div class="col-md-3 col-sm-12 text-left">
               
                <?php echo Form::button('VER CARRITO DE COMPRAS',['class'=>'demo btn  btn-lg', 'data-toggle'=>'modal','id'=>'LookCar', 'href'=>'#responsive','onclick'=>'']); ?>

                  
                  

                   
                </div>
    </div>

</section>

<section class="arreglo-detalles">
    <div class="container">
        <div class="row">
            <div class="col-md-5 img-arreglo-detalles">
                <div class="col-md-12">
                  <img src="/img/arreglos/<?php echo e($producto->imagen); ?>" class="img-responsive">
                  <input type="hidden" id="img" value="<?php echo e($producto->imagen); ?>" name="">
                </div>
                
              
            <!-- -->
            <div class="col-md-12 ">
                <div class="row puntosGanados">
                    <div class="col-md-4 col-sm-6 cuadro text-center">
                        <p><h5>PUNTOS POR COMPRA <strong id="puntos">0</strong></h5></p>
                        

                    </div>
                    <div class="col-md-4 col-sm-6 cuadro text-center">
                        <p><h5>GARANTIA 100% ASEGURADA</h5></p>
                        
                    </div>
                    <div class="col-md-4 col-sm-6 text-center">
                        <p><h5>SITIO WEB SEGURO</h5></p>
                    </div>
                    
                </div>
            </div>

            <!-- -->
            <div class="col-md-12">

                    <button class="btn-comprar" onclick="AgregarProducto()">AGREGAR A CARRITO DE COMPRAS</button>
                    
            </div>

            <!-- -->

            </div>


            <div class="col-md-7">
                <h2><?php echo e($producto->nombre); ?></h2>
                <input type="hidden" value="<?php echo e($producto->nombre); ?>" id="nombreProducto">
                <input type="hidden" id="cc" value="<?php echo e($producto->id); ?>">
                <p>
                    <?php echo e($producto->descripcion); ?>

                </p>

                <input type="hidden" name="" id="valorProducto" value="<?php echo e(number_format($producto->prices->first()->precio)); ?>">
                  <h2 >$ <strong id="precioT"> <?php echo e(number_format($producto->prices->first()->precio)); ?></strong></h2>
            
                
                <div class="cantidad-arreglo">
                    <p class="text-cantidad">Cantidad:</p> 
                    <input type="number" step="1" min="0"  id="cantidadProducto" name="quantity" value="1" title="Cantidad" class="input-text qty text" size="4" />
                </div>
                 <div class="cantidad-arreglo">
                    <p class="text-cantidad">Tamaño:</p> 
                    <?php echo Form::select('selectTamaño',$producto->prices->pluck('tamaño','precio'),null,['class'=>'tamaño-arreglo','id'=>'selectTamaño', 'onchange'=> 'changeFunc();']); ?> 
                    
                </div>
                <div class="detalles-arreglo">
                    <h3>Si quieres sorprender en grande.. <strong>Agrega un detalle.!</strong></h3>
                  <!-- Nav tabs -->
                  <ul class="nav nav-tabs" role="tablist">

                    <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        
                        <li role="presentation">
                            <a href="#<?php echo e($category->name); ?>"  aria-controls="<?php echo e($category->name); ?>" role="tab" data-toggle="tab"><?php echo e($category->name); ?></a>
                        </li>

                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  </ul>
                  <!-- Tab panes -->
                  <div class="tab-content">

                  <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <?php if($category->name ==="Osos"): ?>
                      <div role="tabpanel" class="tab-pane fade in active" id="<?php echo e($category->name); ?>">
                  <?php else: ?>
                       <div role="tabpanel" class="tab-pane" id="<?php echo e($category->name); ?>">
                  <?php endif; ?>
                  
                   
                  
                        <?php $__currentLoopData = $category->products_with_price(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    
                            <div class="col-md-4" data-wow-duration="500ms">
                                <div class="detalle-desc text-center">                                   
                                         <img src="/img/arreglos/<?php echo e($product->imagen); ?>" class="img-responsive">
                                         <input type="hidden" value="<?php echo e($product->imagen); ?>" id="img<?php echo e($product->id); ?>">
                                         <input type="hidden" value="sinTamaño" id="tamDeta">
                                         <input type="hidden" id="<?php echo e($product->id); ?>" value="<?php echo e($product->prices->first()->precio); ?>" name="">
                                        <div class="cantidad-detalle">
                                          <p>Cantidad:</p>
                                          <input type="number" step="1" min="0"  id="cantidadDetalle<?php echo e($product->id); ?>" name="quantity" value="1" title="Cantidad" class="input-text qty text" size="4" />
                                        </div>

                                          <input type="hidden" value="<?php echo e($product->nombre); ?>" id="nombreDetalle<?php echo e($product->id); ?>" name="">
                                          <h5><?php echo e($product->nombre); ?></h5>
                                          <h3><strong> <?php echo e(number_format($product->prices->first()->precio)); ?></strong></h3>

                                          <button onclick="agregarDetalle(<?php echo e($product->id); ?>)" class="btn btn-success form-control">AGREGAR</button>
                                          
                                </div>
                            </div>       
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                   </div>

                    
                </div>
                
                </div>
                
            </div>
       <div class="add-circulo" id="addcirculo">
                <h2> + AGRUEGADO A CARRITO DE COMPRAS</h2>
            
            
        </div>
        
    </div>
    
</section>



<?php echo $__env->make('layouts.productosRelacionados', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.base', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
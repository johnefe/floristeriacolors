<?php $__env->startSection('content'); ?>
<section class="blog" id="blog">
    <div class="parallax-overlays">
    <div class="container ">
        <div class="row">
            <div class="col-md-10 col-md-offset-1 text-center titulo-memoral" >
                <h3>ÁRBOLES MEMORALES</h3>
            </div>
        </div>
        <div class="row  texto-memoral">
            <div class="col-md-6 text-center">
                <div id="myCarousel" class="carousel" data-ride="carousel" style="height: 400px !important">
                  <!-- Wrapper for slides -->
                    <div class="carousel-inner" >

                            <?php $__currentLoopData = $sliders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $slider): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="item t <?php if($slider->id === 7): ?> active  <?php endif; ?> " >
                                 <img src="/img/arreglos/slider/<?php echo e($slider->imagen); ?>" alt="Floristeria Rosas Don Victorio" class="" style="height: 400px !important;">
  
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                         
                </div>
            </div>
            <div class="col-md-6  texto-memoral">
                <?php $__currentLoopData = $sliders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $slider): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php if($slider->id === 7): ?>
                        <p><?php echo e($slider->descripcion); ?></p>
                        
                        <p><strong><?php echo e($slider->nombre); ?></strong></p>
                    <?php endif; ?>
                 <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    </div>
    </div>
</section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.base', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
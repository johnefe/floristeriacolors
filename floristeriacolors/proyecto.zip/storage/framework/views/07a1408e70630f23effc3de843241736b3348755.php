<?php $__env->startSection('content'); ?>

<?php if(Session::has('message')): ?>

<div class="alert alert-success alert-dismissible" role="alert">
  <button type="button" class="close" data-dismiss="alert" aria-label="Close">
  <span aria-hidden="true">&times;</span></button>
  <?php echo e(Session::get('message')); ?></div>

<?php endif; ?>

<div class="col-md-10 col-md-offset-1">
    <div class="card">
        <div class="header">
            <h4 class="title">MIS PRODUCTOS REGISTRADOS</h4>
            <p class="category">www.floristeriaColors.com</p>
        </div>
        <div class="content table-responsive table-full-width ">
            <table class="table table-hover table-striped">
                <thead>
                    <th>Nombre</th>
                    <th>Categoría</th>
                    <th>Descripción</th>
                    <th>Imagen</th>
                    <th>Acciones</th>
                </thead>

                <!--inicio un producto -->
                <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				<tbody>
					<td><?php echo e($product->nombre); ?></td>
					<td><?php echo e($product->category->name); ?></td>
					<td><?php echo e($product->descripcion); ?></td>
					<td><img class="img-responsive" src="/img/arreglos/<?php echo e($product->imagen); ?>">
                    </td>

					<td>
					<a href="/admin/productos/<?php echo e($product->id); ?>/edit" class="btn btn-success"><span class="fa fa-pencil fa-1x"></span></a>
					

		 			<?php echo Form::open(['route'=>['productos.destroy',$product->id],'method'=>'DELETE']); ?>

					<button type="submit" class="btn btn-danger" ><span class="fa fa-trash fa-1x"></span></button>

					<?php echo Form::close(); ?>


					</td>
				</tbody>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            </table>

        </div>
    </div>
</div>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.adminBase', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
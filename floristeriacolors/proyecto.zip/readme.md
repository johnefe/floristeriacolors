Ultima actualizacion el 26 de julio de 2018. by Ingeniero Jhon Frey Diaz  email: jotaefe006@gmail.com

/***********************
pc jhonf
***********************/
/node_modules
/public/storage
/public/hot
/storage/*.key
/vendor
/.idea
Homestead.json
Homestead.yaml
.env
/*conexion local db*/
DB_CONNECTION=mysql
DB_HOST=127.0.0.1
DB_PORT=3306
DB_DATABASE=floristeriacolors
DB_USERNAME=root
DB_PASSWORD='udenar'
/*-----------------------------*/
/*conexion con el servidor db*/
DB_CONNECTION=mysql
DB_HOST=localhost
DB_PORT=3306
DB_DATABASE=floristeriacolors
DB_USERNAME=janetharcosdm
DB_PASSWORD='23086791'
/*------------------------------*/
DB_CONNECTION=mysql
DB_HOST=localhost
DB_PORT=3306
DB_DATABASE=donvictorio
DB_USERNAME=root
DB_PASSWORD=''
/*------------------------------*/
floristeriacolors db
usuario: janetharcosdm
db: floristeriacolors
pass: 23086791
ftp:
usuario: 
pass: floristeriacolors2018
-----------------------------------------------
Servidor para filezilla
107.180.48.125
usuario:floristeriacolor
pass:
-----------------------------------------------
nomero de usuario
 113256580
contra
 23086791dM
 en goodaddy

cpanel
floristeriacolor
pass:#Floristeria2
https://www.youtube.com/watch?v=5l16JWh5krw

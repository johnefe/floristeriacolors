<?php

namespace FloristeriaColors;

use Illuminate\Database\Eloquent\Model;

class City extends Model
{
    //
}
